package AI;

import motor.Board;
import motor.Player;
import motor.Team;
import motor.TurnResponse;

public class CoucAI extends Player {
    public CoucAI(Team team) {
    }

    @Override
    public TurnResponse Play(Board boardCopy) {
        return null;
    }
}
