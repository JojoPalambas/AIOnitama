package motor;

public abstract class Player {
    public abstract TurnResponse Play(Board boardCopy);
}
