package motor;

public enum Team {
    none,
    A,
    B
}
