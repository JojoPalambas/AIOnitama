package motor;

public class Piece {
    public PieceType type;
    public Team team;

    public Piece(PieceType type, Team team) {
        this.type = type;
        this.team = team;
    }
}
