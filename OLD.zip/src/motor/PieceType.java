package motor;

public enum PieceType {
    king,
    monk
}
